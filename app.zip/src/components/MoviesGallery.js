import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchMovies, setSearchFilter, setYearFilter, setModalMovie, closeModal } from '../features/movies/moviesActions';
import { Container, TextField, Button, Grid, Pagination, Typography, Box, MenuItem, Select, FormControl, InputLabel } from '@mui/material';
import MovieCard from './MovieCard';
import MovieModal from './MovieModal';

function MoviesGallery() {
  const dispatch = useDispatch();
  const { list: movies, loading, error, modalMovie, totalPages, filters } = useSelector((state) => state.movies);

  // Local state for pagination and filters
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [year, setYear] = useState('');
  const [genre, setGenre] = useState('');
  const [language, setLanguage] = useState('');

  // Fetch movies on mount and on page change
  useEffect(() => {
    dispatch(fetchMovies(currentPage, filters)); 
  }, [dispatch, currentPage, filters]);

  // Handle search input change
  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  // Handle filter changes
  const handleYearChange = (e) => {
    setYear(e.target.value);
  };

  const handleGenreChange = (e) => {
    setGenre(e.target.value);
  };

  const handleLanguageChange = (e) => {
    setLanguage(e.target.value);
  };

  // Handle search submit
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    dispatch(setSearchFilter(search));
    dispatch(setYearFilter(year));
    setCurrentPage(1);  // Reset to page 1
    dispatch(fetchMovies(1, { query: search, primary_release_year: year, genre, language }));
  };

  // Handle opening the modal
  const openModal = (movie) => {
    dispatch(setModalMovie(movie));
  };

  // Handle closing the modal
  const closeModalHandler = () => {
    dispatch(closeModal());
  };

  // Handle pagination change
  const handleNextPage = (event, value) => {
    setCurrentPage(value);
  };

  if (loading) return <Typography variant="h4" color="primary">Loading...</Typography>;
  if (error) return <Typography variant="h4" color="error">Error: {error}</Typography>;

  return (
    <Container maxWidth="lg" sx={{ py: 4, color: '#fff', minHeight: '100vh' }}>
      <img src={require("../images/background.jpg")} alt="Background" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1, opacity: 0.5 }} />
      {/* Search and Filter Form */}
      <Grid container spacing={3}>
        {/* Filter Area */}
        <Grid item xs={12} md={3}>
        <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column', gap: 2 }}>
          <img src={require("../images/Icon.png")} alt="Logo" width={300}  />
        </Container>
          <Box sx={{ bgcolor: '#2c2c2c', p: 2, borderRadius: 2 }}>
            <Typography variant="h6" color="primary" mb={2}>Filters</Typography>
            
            {/* Filter by Year */}
            <TextField
              label="Filter by Year"
              variant="outlined"
              type="number"
              value={year}
              onChange={handleYearChange}
              fullWidth
              sx={{ mb: 2, bgcolor: '#2c2c2c', input: { color: 'white' }, label: { color: '#888' }, borderRadius: 1 }}
              InputLabelProps={{ style: { color: '#888' } }}
            />

            {/* Filter by Genre */}
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel sx={{ color: '#888' }}>Genre</InputLabel>
              <Select
                value={genre}
                label="Genre"
                onChange={handleGenreChange}
                sx={{ color: 'white', bgcolor: '#2c2c2c' }}
              >
                <MenuItem value="action">Action</MenuItem>
                <MenuItem value="comedy">Comedy</MenuItem>
                <MenuItem value="drama">Drama</MenuItem>
                <MenuItem value="horror">Horror</MenuItem>
              </Select>
            </FormControl>

            {/* Filter by Language */}
            <FormControl fullWidth>
              <InputLabel sx={{ color: '#888' }}>Language</InputLabel>
              <Select
                value={language}
                label="Language"
                onChange={handleLanguageChange}
                sx={{ color: 'white', bgcolor: '#2c2c2c' }}
              >
                <MenuItem value="en">English</MenuItem>
                <MenuItem value="es">Spanish</MenuItem>
                <MenuItem value="fr">French</MenuItem>
                <MenuItem value="ja">Japanese</MenuItem>
              </Select>
            </FormControl>
          </Box>
          
        </Grid>
        {/* Main Movie Grid */}
        <Grid item xs={12} md={9}>
          <Box component="form" onSubmit={handleSearchSubmit} display="flex" gap={2} mb={4}>
            <TextField
              label="Search Movies"
              variant="outlined"
              value={search}
              onChange={handleSearchChange}
              fullWidth
              sx={{ bgcolor: '#2c2c2c', input: { color: 'white' }, label: { color: '#888' }, borderRadius: 1 }}
              InputLabelProps={{ style: { color: '#888' } }}
            />
            <Button type="submit" variant="contained" color="primary" sx={{ height: '56px' }}>
              Search
            </Button>
          </Box>

          {/* Movie Cards Grid */}
          <Grid container spacing={3}>
            {movies.map((movie) => (
              <Grid item xs={6} sm={4} md={3} key={movie.id}>
                <MovieCard movie={movie} openModal={openModal} />
              </Grid>
            ))}
          </Grid>

          {/* Pagination */}
          <Box mt={4} display="flex" justifyContent="center">
            <Pagination
              count={totalPages}
              page={currentPage}
              onChange={handleNextPage}
              color="primary"
              size="medium"
              sx={{ '& .MuiPaginationItem-root': { color: '#fff' } }}
            />
          </Box>
        </Grid>

        
      </Grid>

      {/* Movie Details Modal */}
      {modalMovie && (
        <MovieModal movie={modalMovie} closeModal={closeModalHandler} />
      )}
    </Container>
  );
}

export default MoviesGallery;
