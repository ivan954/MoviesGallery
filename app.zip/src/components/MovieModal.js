import React from 'react';
import { Dialog, DialogContent, DialogTitle, Typography, Box, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

function MovieModal({ movie, closeModal }) {
  return (
    <Dialog open={true} onClose={closeModal} fullWidth maxWidth="md" PaperProps={{ sx: { bgcolor: '#1c1c1c', color: 'white' } }}>
      <DialogTitle sx={{ m: 0, p: 2 }}>
        {movie.title}
        <IconButton
          aria-label="close"
          onClick={closeModal}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: 'white',
          }}
        >
          <CloseIcon />
        </IconButton>
      </DialogTitle>
      <DialogContent>
        <Box display="flex" gap={2}>
          <Box flex={1}>
            <img
              src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
              alt={movie.title}
              style={{ width: '100%' }}
            />
          </Box>
          <Box flex={2}>
            <Typography variant="body1" paragraph>
              {movie.overview}
            </Typography>
            <Typography variant="subtitle1">Release Date: {movie.release_date}</Typography>
            <Typography variant="subtitle1">Rating: {movie.vote_average} ⭐</Typography>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
}

export default MovieModal;
