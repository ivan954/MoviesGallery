import React from 'react'
import './App.css'
import MoviesGallery from './components/MoviesGallery'

function App() {
  return (
    <div>
      <MoviesGallery />
    </div>
  )
}

export default App
