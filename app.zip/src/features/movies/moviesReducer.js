import {
  FETCH_MOVIES_REQUEST,
  FETCH_MOVIES_SUCCESS,
  FETCH_MOVIES_FAILURE,
  ADD_MOVIE,
  UPDATE_MOVIE,
  DELETE_MOVIE,
  SET_SEARCH_FILTER,
  SET_YEAR_FILTER,
  SET_MODAL_MOVIE,
  CLOSE_MODAL,
} from './moviesTypes';

const initialState = {
  list: [], 
  loading: false,
  error: null,
  totalPages: 1,
  filters: {
    year: '',
    genre: '',
    language: '',
    runtime: '',
    minimumUserVotes: '',
    search: '', 
  },
  modalMovie: null, 
};

const moviesReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_MOVIES_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case FETCH_MOVIES_SUCCESS:
      return {
        ...state,
        loading: false,
        list: action.payload.results,  
        totalPages: action.payload.totalPages,
      };
    case FETCH_MOVIES_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case SET_SEARCH_FILTER:
      return {
        ...state,
        filters: { ...state.filters, search: action.payload },
      };
    case SET_YEAR_FILTER:
      return {
        ...state,
        filters: { ...state.filters, year: action.payload }, 
      };
    case SET_MODAL_MOVIE:
      return {
        ...state,
        modalMovie: action.payload, 
      };
    case CLOSE_MODAL:
      return {
        ...state,
        modalMovie: null, 
      };
    case ADD_MOVIE:
      return {
        ...state,
        list: [...state.list, action.payload],
      };
    case UPDATE_MOVIE:
      return {
        ...state,
        list: state.list.map((movie) =>
          movie.id === action.payload.id ? action.payload : movie
        ),
      };
    case DELETE_MOVIE:
      return {
        ...state,
        list: state.list.filter((movie) => movie.id !== action.payload),
      };
    default:
      return state;
  }
};

export default moviesReducer;
