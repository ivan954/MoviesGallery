import axios from 'axios';
import {
  FETCH_MOVIES_REQUEST,
  FETCH_MOVIES_SUCCESS,
  FETCH_MOVIES_FAILURE,
  SET_SEARCH_FILTER,
  SET_YEAR_FILTER,
  SET_MODAL_MOVIE,
  CLOSE_MODAL,
  ADD_MOVIE,
  UPDATE_MOVIE,
  DELETE_MOVIE,
} from './moviesTypes';

const API_KEY = 'c033f5b4649da5cc07266010655f43f7';
const API_URL = `https://api.themoviedb.org/3/discover/movie`;

// Thunk for fetching movies from The Movie DB API
export const fetchMovies = (page = 1, filters = {}) => {
  return async (dispatch) => {
    dispatch({ type: FETCH_MOVIES_REQUEST });

    try {
      let apiUrl = API_URL; 

      if (filters.search) {
        apiUrl = API_URL;
      }

      const params = {
        api_key: API_KEY,
        page,
      };

      // Only include filters if they have a value
      if (filters.search) {
        params.query = filters.search;
      }
      if (filters.year) {
        params.primary_release_year = filters.year;
      }
      const response = await axios.get(apiUrl, { params });

      dispatch({
        type: FETCH_MOVIES_SUCCESS,
        payload: {
          results: response.data.results, 
          totalPages: response.data.total_pages, 
        },
      });
    } catch (error) {
      dispatch({
        type: FETCH_MOVIES_FAILURE,
        payload: error.message,
      });
    }
  };
};

// Other action creators remain the same
export const setSearchFilter = (search) => ({
  type: SET_SEARCH_FILTER,
  payload: search,
});

export const setYearFilter = (year) => ({
  type: SET_YEAR_FILTER,
  payload: year,
});

export const setModalMovie = (movie) => ({
  type: SET_MODAL_MOVIE,
  payload: movie,
});

export const closeModal = () => ({
  type: CLOSE_MODAL,
});

export const addMovie = (movie) => ({
  type: ADD_MOVIE,
  payload: movie,
});

export const updateMovie = (movie) => ({
  type: UPDATE_MOVIE,
  payload: movie,
});

export const deleteMovie = (id) => ({
  type: DELETE_MOVIE,
  payload: id,
});
