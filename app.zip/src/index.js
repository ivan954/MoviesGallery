import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';  // Import Provider from react-redux
import { store } from './store';         // Import your Redux store
import App from './App';

// Create the root
const root = ReactDOM.createRoot(document.getElementById('root'));

// Wrap the App with Provider and pass the store
root.render(
  <React.StrictMode>
    <Provider store={store}>
      <App />
    </Provider>
  </React.StrictMode>
);
